package com.funtarget.app;

import android.os.Bundle;
import android.view.View;
import android.webkit.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        WebView web = findViewById(R.id.webview);

        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);

        web.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        web.setWebViewClient(new WebViewClient(){
            @Override
            public void onReceivedError(
                    WebView v, WebResourceRequest r, WebResourceError e
            ){
                v.loadUrl("file:///android_asset/offline.html");
            }
        });

        web.loadUrl("https://narayanbalai100-a11y.github.io/FunTarget-1/");
    }
}
