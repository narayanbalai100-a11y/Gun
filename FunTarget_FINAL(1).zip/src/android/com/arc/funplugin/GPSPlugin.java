package com.arc.funplugin;

import android.content.Context;
import android.content.Intent;
import android.location.LocationManager;
import android.provider.Settings;
import org.apache.cordova.*;
import org.json.JSONArray;

public class GPSPlugin extends CordovaPlugin {

    @Override
    public boolean execute(String action, JSONArray args, CallbackContext cb) {
        if(action.equals("getStatus")){
            LocationManager lm = (LocationManager)cordova.getActivity().getSystemService(Context.LOCATION_SERVICE);
            boolean gps = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
            boolean net = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
            cb.success((gps||net) ? "OK" : "OFF");
            return true;
        }

        if(action.equals("openSettings")){
            Intent i = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            cordova.getActivity().startActivity(i);
            return true;
        }
        return false;
    }
}
